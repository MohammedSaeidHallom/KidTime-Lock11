package com.example.ui.tabs

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.TimerStatus
import com.example.ui.components.ParentPinDialog
import com.example.ui.components.TimerCircle
import com.example.ui.theme.Amber400
import com.example.ui.theme.Cyan400
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkCardBorder
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.Emerald500
import com.example.ui.theme.Red500
import com.example.ui.theme.Slate800
import kotlin.math.roundToInt

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun TimerScreen(
    remainingSeconds: Long,
    totalSeconds: Long,
    status: TimerStatus,
    targetMinutes: Int,
    parentPin: String,
    pinRequiredToStop: Boolean,
    isDeviceAdminActive: Boolean,
    onStartTimer: (minutes: Int) -> Unit,
    onPauseTimer: () -> Unit,
    onResumeTimer: () -> Unit,
    onStopTimer: () -> Unit,
    onAddFiveMinutes: () -> Unit,
    onSubtractFiveMinutes: () -> Unit,
    onRequestDeviceAdmin: () -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedMinutes by remember { mutableIntStateOf(targetMinutes.coerceIn(1, 120)) }
    var pendingAction by remember { mutableStateOf(TimerAction.NONE) }

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = modifier
            .fillMaxSize()
            .background(DarkBackground)
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 16.dp)
    ) {
        // Warning Banner if Device Admin is not granted
        AnimatedVisibility(visible = !isDeviceAdminActive) {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Slate800),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(Amber400.copy(alpha = 0.5f))),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp)
                    .clickable { onRequestDeviceAdmin() }
                    .testTag("admin_warning_banner")
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(14.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Security,
                        contentDescription = null,
                        tint = Amber400,
                        modifier = Modifier.size(28.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "تفعيل صلاحية قفل الهاتف التلقائي",
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            fontSize = 13.sp
                        )
                        Text(
                            text = "انقر هنا لتفعيل قفل الشاشة الإجباري فور انتهاء الوقت",
                            color = Amber400,
                            fontSize = 11.sp
                        )
                    }
                }
            }
        }

        // Circular Countdown Timer
        TimerCircle(
            remainingSeconds = remainingSeconds,
            totalSeconds = totalSeconds,
            status = status,
            targetMinutes = if (status == TimerStatus.IDLE) selectedMinutes else targetMinutes,
            modifier = Modifier.padding(vertical = 12.dp)
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Time Adjustment Controls - idle: ±1 minute, running: protected by Parent PIN
        Row(
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
                .clip(RoundedCornerShape(20.dp))
                .background(DarkSurface)
                .border(1.dp, DarkCardBorder, RoundedCornerShape(20.dp))
                .padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            // Subtract
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .size(44.dp)
                    .clip(CircleShape)
                    .background(Slate800)
                    .clickable {
                        if (status == TimerStatus.IDLE || status == TimerStatus.FINISHED) {
                            selectedMinutes = (selectedMinutes - 1).coerceIn(1, 120)
                        } else {
                            // Require parent PIN to modify running countdown
                            pendingAction = TimerAction.SUBTRACT_TIME
                        }
                    }
                    .testTag("btn_sub_5m")
            ) {
                Icon(
                    imageVector = Icons.Default.Remove,
                    contentDescription = "-5 دقائق",
                    tint = Cyan400
                )
            }

            Spacer(modifier = Modifier.width(20.dp))

            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = if (status == TimerStatus.IDLE || status == TimerStatus.FINISHED) "$selectedMinutes دقيقة" else "تعديل الوقت 🔒",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
                Text(
                    text = if (status == TimerStatus.IDLE || status == TimerStatus.FINISHED) "زيادة أو إنقاص دقيقة واحدة (1 - 120)" else "محمي برمز الوالدين لمنع الطفل",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Spacer(modifier = Modifier.width(20.dp))

            // Add
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .size(44.dp)
                    .clip(CircleShape)
                    .background(Slate800)
                    .clickable {
                        if (status == TimerStatus.IDLE || status == TimerStatus.FINISHED) {
                            selectedMinutes = (selectedMinutes + 1).coerceIn(1, 120)
                        } else {
                            // Require parent PIN to modify running countdown
                            pendingAction = TimerAction.ADD_TIME
                        }
                    }
                    .testTag("btn_add_5m")
            ) {
                Icon(
                    imageVector = Icons.Default.Add,
                    contentDescription = "+5 دقائق",
                    tint = Cyan400
                )
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Idle configuration: choose every minute from 1 to 120
        if (status == TimerStatus.IDLE) {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurface),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(DarkCardBorder)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text(
                        text = "اختيار مدة الطفل بالدقيقة ⏱️",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = "المدة المختارة: $selectedMinutes دقيقة (من 1 إلى 120)",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Slider(
                        value = selectedMinutes.toFloat(),
                        onValueChange = { selectedMinutes = it.roundToInt().coerceIn(1, 120) },
                        valueRange = 1f..120f,
                        steps = 118, // 120 minute positions = 118 steps between 1 and 120
                        colors = SliderDefaults.colors(
                            thumbColor = Cyan400,
                            activeTrackColor = Cyan400,
                            inactiveTrackColor = Slate800
                        ),
                        modifier = Modifier.testTag("timer_slider")
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Main Action Buttons
        when (status) {
            TimerStatus.IDLE -> {
                Button(
                    onClick = { onStartTimer(selectedMinutes) },
                    colors = ButtonDefaults.buttonColors(containerColor = Cyan400, contentColor = DarkBackground),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(56.dp)
                        .testTag("btn_start_timer")
                ) {
                    Icon(
                        imageVector = Icons.Default.PlayArrow,
                        contentDescription = null,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "تشغيل المؤقت وقفل الهاتف بعد $selectedMinutes دقيقة",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
            TimerStatus.RUNNING -> {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    // Pause - requires PIN
                    Button(
                        onClick = { pendingAction = TimerAction.PAUSE },
                        colors = ButtonDefaults.buttonColors(containerColor = Amber400, contentColor = DarkBackground),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(54.dp)
                            .testTag("btn_pause_timer")
                    ) {
                        Icon(imageVector = Icons.Default.Pause, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(text = "إيقاف مؤقت", fontWeight = FontWeight.Bold)
                    }

                    // Stop - requires PIN
                    Button(
                        onClick = { pendingAction = TimerAction.STOP },
                        colors = ButtonDefaults.buttonColors(containerColor = Red500, contentColor = Color.White),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(54.dp)
                            .testTag("btn_stop_timer")
                    ) {
                        Icon(imageVector = Icons.Default.Stop, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(text = "إنهاء المؤقت", fontWeight = FontWeight.Bold)
                    }
                }
            }
            TimerStatus.PAUSED -> {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    // Resume
                    Button(
                        onClick = onResumeTimer,
                        colors = ButtonDefaults.buttonColors(containerColor = Emerald500, contentColor = Color.White),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(54.dp)
                            .testTag("btn_resume_timer")
                    ) {
                        Icon(imageVector = Icons.Default.PlayArrow, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(text = "استئناف المؤقت", fontWeight = FontWeight.Bold)
                    }

                    // Stop - requires PIN
                    Button(
                        onClick = { pendingAction = TimerAction.STOP },
                        colors = ButtonDefaults.buttonColors(containerColor = Red500, contentColor = Color.White),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(54.dp)
                            .testTag("btn_stop_timer")
                    ) {
                        Icon(imageVector = Icons.Default.Stop, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(text = "إنهاء الجلسة", fontWeight = FontWeight.Bold)
                    }
                }
            }
            TimerStatus.FINISHED -> {
                Button(
                    onClick = { onStartTimer(selectedMinutes) },
                    colors = ButtonDefaults.buttonColors(containerColor = Cyan400, contentColor = DarkBackground),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(56.dp)
                        .testTag("btn_restart_timer")
                ) {
                    Text(text = "بدء جلسة جديدة للطفل", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Child Protection info note
        Text(
            text = "💡 بعد بدء المؤقت، يمكنك الخروج من التطبيق وسيعمل في الخلفية. عندما ينتهي الوقت سيتم قفل الهاتف مباشرة وتطبيق شاشة القفل.",
            fontSize = 11.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
            lineHeight = 16.sp,
            modifier = Modifier.padding(horizontal = 12.dp)
        )
    }

    // Parent PIN Verification Dialog for all protected actions
    if (pendingAction != TimerAction.NONE) {
        val (actionTitle, actionDesc) = when (pendingAction) {
            TimerAction.ADD_TIME -> "زيادة وقت المؤقت (+5 دقائق)" to "أدخل رمز الوالدين لتأكيد زيادة الوقت المسموح للطفل"
            TimerAction.SUBTRACT_TIME -> "إنقاص وقت المؤقت (-5 دقائق)" to "أدخل رمز الوالدين لتأكيد إنقاص وقت الشاشة للطفل"
            TimerAction.PAUSE -> "إيقاف المؤقت مؤقتاً" to "أدخل رمز الوالدين لتأكيد إيقاف العد التنازلي مؤقتاً"
            TimerAction.STOP -> "إنهاء المؤقت المبكر" to "أدخل رمز الوالدين لتأكيد إيقاف المؤقت قبل انتهاء وقته"
            TimerAction.NONE -> "" to ""
        }

        ParentPinDialog(
            correctPin = parentPin,
            title = actionTitle,
            description = actionDesc,
            onPinSuccess = {
                val act = pendingAction
                pendingAction = TimerAction.NONE
                when (act) {
                    TimerAction.ADD_TIME -> onAddFiveMinutes()
                    TimerAction.SUBTRACT_TIME -> onSubtractFiveMinutes()
                    TimerAction.PAUSE -> onPauseTimer()
                    TimerAction.STOP -> onStopTimer()
                    TimerAction.NONE -> {}
                }
            },
            onDismiss = { pendingAction = TimerAction.NONE }
        )
    }
}

enum class TimerAction {
    NONE,
    ADD_TIME,
    SUBTRACT_TIME,
    PAUSE,
    STOP
}