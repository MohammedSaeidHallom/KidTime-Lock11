package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.QueryStats
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.Cyan400
import com.example.ui.theme.DarkCardBorder
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.Emerald500
import com.example.ui.theme.Slate800

@Composable
fun PermissionCard(
    isDeviceAdminActive: Boolean,
    hasUsageStatsPermission: Boolean,
    hasNotificationPermission: Boolean,
    hasOverlayPermission: Boolean,
    onRequestDeviceAdmin: () -> Unit,
    onRequestUsageStats: () -> Unit,
    onRequestNotification: () -> Unit,
    onRequestOverlay: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = DarkSurface),
        border = BorderStroke(1.dp, DarkCardBorder),
        modifier = modifier
            .fillMaxWidth()
            .testTag("permissions_health_card")
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            Text(
                text = "صلاحيات القفل والمراقبة 🛡️",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )

            Spacer(modifier = Modifier.height(14.dp))

            // 1. Device Admin Lock
            PermissionItemRow(
                icon = Icons.Default.Lock,
                title = "قفل الشاشة التلقائي (مسؤول الجهاز)",
                description = "لإطفاء الشاشة وإجبار طلب البصمة/الرمز فور انتهاء الوقت",
                isGranted = isDeviceAdminActive,
                onRequest = onRequestDeviceAdmin,
                testTag = "btn_grant_admin"
            )

            Spacer(modifier = Modifier.height(12.dp))

            // 2. Usage Stats
            PermissionItemRow(
                icon = Icons.Default.QueryStats,
                title = "تتبع التطبيقات المستخدمة",
                description = "لعرض قائمة وإحصائيات التطبيقات التي فتحها الطفل",
                isGranted = hasUsageStatsPermission,
                onRequest = onRequestUsageStats,
                testTag = "btn_grant_usage"
            )

            Spacer(modifier = Modifier.height(12.dp))

            // 3. Notifications
            PermissionItemRow(
                icon = Icons.Default.Notifications,
                title = "إشعار المؤقت والعمل بالخلفية",
                description = "لعرض العد التنازلي لوقت الشاشة المتبقي والتنبيه عند الانتهاء",
                isGranted = hasNotificationPermission,
                onRequest = onRequestNotification,
                testTag = "btn_grant_notif"
            )

            Spacer(modifier = Modifier.height(12.dp))

            // 4. Display over other apps (exercise and lock screen appear directly on screen)
            PermissionItemRow(
                icon = Icons.Default.Visibility,
                title = "الظهور فوق التطبيقات",
                description = "ليظهر التمرين وشاشة القفل مباشرة على الشاشة فوق أي تطبيق يفتحه الطفل",
                isGranted = hasOverlayPermission,
                onRequest = onRequestOverlay,
                testTag = "btn_grant_overlay"
            )
        }
    }
}

@Composable
private fun PermissionItemRow(
    icon: ImageVector,
    title: String,
    description: String,
    isGranted: Boolean,
    onRequest: () -> Unit,
    testTag: String
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.weight(1f)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = if (isGranted) Cyan400 else MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(24.dp)
            )

            Spacer(modifier = Modifier.width(12.dp))

            Column {
                Text(
                    text = title,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = Color.White
                )
                Text(
                    text = description,
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    lineHeight = 14.sp
                )
            }
        }

        Spacer(modifier = Modifier.width(8.dp))

        if (isGranted) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(horizontal = 8.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.CheckCircle,
                    contentDescription = "مفعل",
                    tint = Emerald500,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = "مُفعّل",
                    color = Emerald500,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        } else {
            FilledTonalButton(
                onClick = onRequest,
                colors = ButtonDefaults.filledTonalButtonColors(
                    containerColor = Slate800,
                    contentColor = Cyan400
                ),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.testTag(testTag)
            ) {
                Text(text = "تفعيل", fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}
