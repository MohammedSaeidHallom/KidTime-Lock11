package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.TimerStatus
import com.example.ui.theme.Amber400
import com.example.ui.theme.Cyan400
import com.example.ui.theme.Emerald500
import com.example.ui.theme.Indigo500
import com.example.ui.theme.Red500
import com.example.ui.theme.Slate700
import com.example.ui.theme.Slate800

@Composable
fun TimerCircle(
    remainingSeconds: Long,
    totalSeconds: Long,
    status: TimerStatus,
    targetMinutes: Int,
    size: Dp = 260.dp,
    modifier: Modifier = Modifier
) {
    val progress = if (totalSeconds > 0) {
        (remainingSeconds.toFloat() / totalSeconds.toFloat()).coerceIn(0f, 1f)
    } else {
        1f
    }

    val animatedProgress by animateFloatAsState(
        targetValue = progress,
        animationSpec = tween(durationMillis = 600, easing = FastOutSlowInEasing),
        label = "timerProgress"
    )

    val ringColor = when (status) {
        TimerStatus.RUNNING -> if (remainingSeconds <= 60) Red500 else Cyan400
        TimerStatus.PAUSED -> Amber400
        TimerStatus.FINISHED -> Red500
        TimerStatus.IDLE -> Indigo500
    }

    val minutes = if (status == TimerStatus.IDLE) targetMinutes else (remainingSeconds / 60).toInt()
    val seconds = if (status == TimerStatus.IDLE) 0 else (remainingSeconds % 60).toInt()
    val timeFormatted = String.format("%02d:%02d", minutes, seconds)

    Box(
        contentAlignment = Alignment.Center,
        modifier = modifier
            .size(size)
            .clip(CircleShape)
    ) {
        Canvas(modifier = Modifier.size(size)) {
            val strokeWidth = 14.dp.toPx()
            val arcSize = size.toPx() - strokeWidth
            val topLeft = Offset(strokeWidth / 2f, strokeWidth / 2f)

            // Background subtle track
            drawArc(
                color = Slate800,
                startAngle = 0f,
                sweepAngle = 360f,
                useCenter = false,
                topLeft = topLeft,
                size = Size(arcSize, arcSize),
                style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
            )

            // Inner guide ring
            drawArc(
                color = Slate700.copy(alpha = 0.4f),
                startAngle = -90f,
                sweepAngle = 360f,
                useCenter = false,
                topLeft = topLeft,
                size = Size(arcSize, arcSize),
                style = Stroke(width = 2.dp.toPx(), cap = StrokeCap.Round)
            )

            // Animated Progress ring
            val sweep = animatedProgress * 360f
            if (sweep > 0f) {
                drawArc(
                    brush = Brush.sweepGradient(
                        listOf(
                            ringColor.copy(alpha = 0.8f),
                            ringColor,
                            ringColor.copy(alpha = 0.9f)
                        )
                    ),
                    startAngle = -90f,
                    sweepAngle = sweep,
                    useCenter = false,
                    topLeft = topLeft,
                    size = Size(arcSize, arcSize),
                    style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
                )
            }
        }

        // Center Content
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(16.dp)
        ) {
            // Status Tag
            val (statusText, statusBg, statusColor) = when (status) {
                TimerStatus.RUNNING -> Triple("قيد التشغيل ⏳", Emerald500.copy(alpha = 0.2f), Emerald500)
                TimerStatus.PAUSED -> Triple("متوقف مؤقتاً ⏸", Amber400.copy(alpha = 0.2f), Amber400)
                TimerStatus.FINISHED -> Triple("انتهى الوقت 🔒", Red500.copy(alpha = 0.2f), Red500)
                TimerStatus.IDLE -> Triple("جاهز للتفعيل ⏱", Indigo500.copy(alpha = 0.2f), Cyan400)
            }

            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .background(statusBg)
                    .padding(horizontal = 10.dp, vertical = 4.dp)
            ) {
                Text(
                    text = statusText,
                    color = statusColor,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Time Display
            Text(
                text = timeFormatted,
                style = MaterialTheme.typography.displayMedium,
                fontWeight = FontWeight.ExtraBold,
                color = Color.White,
                letterSpacing = 2.sp
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = if (status == TimerStatus.IDLE) {
                    "المدة المحددة: $targetMinutes دقيقة"
                } else {
                    "الهدف الإجمالي: $targetMinutes دقيقة"
                },
                fontSize = 13.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
