package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AppDatabase
import com.example.data.PreferencesManager
import com.example.model.AppUsageInfo
import com.example.model.MathQuestionEntity
import com.example.model.ParentSettings
import com.example.model.SessionEntity
import com.example.model.TimerStatus
import com.example.service.KidTimerService
import com.example.util.DeviceLockManager
import com.example.util.UsageStatsHelper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.getInstance(application)
    private val sessionDao = db.sessionDao()
    private val mathQuestionDao = db.mathQuestionDao()
    private val preferencesManager = PreferencesManager(application)
    val deviceLockManager = DeviceLockManager(application)
    val usageStatsHelper = UsageStatsHelper(application)

    // Observables from Service
    val remainingSeconds: StateFlow<Long> = KidTimerService.remainingSeconds
    val totalSeconds: StateFlow<Long> = KidTimerService.totalSeconds
    val timerStatus: StateFlow<TimerStatus> = KidTimerService.status
    val targetMinutes: StateFlow<Int> = KidTimerService.targetMinutes

    // Settings
    val settings: StateFlow<ParentSettings> = preferencesManager.settings

    // History Sessions from Room DB
    val sessions: StateFlow<List<SessionEntity>> = sessionDao.getAllSessions()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Math Questions from Room DB
    val mathQuestions: StateFlow<List<MathQuestionEntity>> = mathQuestionDao.getAllQuestions()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Usage Stats
    private val _appsUsageList = MutableStateFlow<List<AppUsageInfo>>(emptyList())
    val appsUsageList: StateFlow<List<AppUsageInfo>> = _appsUsageList.asStateFlow()

    // Permission flags
    private val _isDeviceAdminActive = MutableStateFlow(deviceLockManager.isDeviceAdminActive())
    val isDeviceAdminActive: StateFlow<Boolean> = _isDeviceAdminActive.asStateFlow()

    private val _hasUsageStatsPermission = MutableStateFlow(deviceLockManager.hasUsageStatsPermission())
    val hasUsageStatsPermission: StateFlow<Boolean> = _hasUsageStatsPermission.asStateFlow()

    private val _hasNotificationPermission = MutableStateFlow(deviceLockManager.hasNotificationPermission())
    val hasNotificationPermission: StateFlow<Boolean> = _hasNotificationPermission.asStateFlow()

    private val _hasOverlayPermission = MutableStateFlow(deviceLockManager.hasOverlayPermission())
    val hasOverlayPermission: StateFlow<Boolean> = _hasOverlayPermission.asStateFlow()

    init {
        checkPermissions()
        loadUsageStats()
        seedDefaultMathQuestionsIfNeeded()
    }

    private fun seedDefaultMathQuestionsIfNeeded() {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                if (mathQuestionDao.getCount() == 0) {
                    val sampleQuestions = listOf(
                        MathQuestionEntity(questionText = "5 + 7 = ؟", correctAnswer = "12", wrongOption1 = "11", wrongOption2 = "13", isCustom = false, difficulty = 1),
                        MathQuestionEntity(questionText = "9 + 6 = ؟", correctAnswer = "15", wrongOption1 = "14", wrongOption2 = "16", isCustom = false, difficulty = 1),
                        MathQuestionEntity(questionText = "14 - 6 = ؟", correctAnswer = "8", wrongOption1 = "7", wrongOption2 = "9", isCustom = false, difficulty = 2),
                        MathQuestionEntity(questionText = "4 × 3 = ؟", correctAnswer = "12", wrongOption1 = "10", wrongOption2 = "14", isCustom = false, difficulty = 3)
                    )
                    sampleQuestions.forEach { mathQuestionDao.insertQuestion(it) }
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    fun checkPermissions() {
        _isDeviceAdminActive.value = deviceLockManager.isDeviceAdminActive()
        _hasUsageStatsPermission.value = deviceLockManager.hasUsageStatsPermission()
        _hasNotificationPermission.value = deviceLockManager.hasNotificationPermission()
        _hasOverlayPermission.value = deviceLockManager.hasOverlayPermission()
    }

    fun loadUsageStats() {
        viewModelScope.launch(Dispatchers.IO) {
            val startTime = KidTimerService.sessionStartTime.value
            val now = System.currentTimeMillis()
            val effectiveStart = if (startTime > 0 && startTime < now) startTime else (now - 15 * 60 * 1000L)
            val stats = usageStatsHelper.getAppsUsedDuringSession(effectiveStart, now)
            _appsUsageList.value = stats
        }
    }

    fun startTimer(minutes: Int) {
        KidTimerService.start(getApplication(), minutes)
        loadUsageStats()
    }

    fun pauseTimer() {
        KidTimerService.pause(getApplication())
    }

    fun resumeTimer() {
        KidTimerService.resume(getApplication())
    }

    fun stopTimer() {
        KidTimerService.stop(getApplication())
        loadUsageStats()
    }

    fun addFiveMinutes() {
        KidTimerService.addFiveMinutes(getApplication())
    }

    fun subtractFiveMinutes() {
        KidTimerService.subtractFiveMinutes(getApplication())
    }

    fun clearHistory() {
        viewModelScope.launch(Dispatchers.IO) {
            sessionDao.clearAll()
        }
    }

    fun saveParentPin(pin: String) {
        preferencesManager.savePin(pin)
    }

    fun updateSettings(
        pinRequiredToStop: Boolean,
        useDeviceAdminLock: Boolean,
        useOverlayLockScreen: Boolean,
        warningSoundBeforeOneMinute: Boolean,
        vibrateOnLock: Boolean,
        mathChallengeEnabled: Boolean = settings.value.mathChallengeEnabled,
        mathChallengeIntervalMinutes: Int = settings.value.mathChallengeIntervalMinutes,
        mathChallengeDurationSeconds: Int = settings.value.mathChallengeDurationSeconds,
        appLockEnabled: Boolean = settings.value.appLockEnabled
    ) {
        preferencesManager.updateSettings(
            pinRequiredToStop = pinRequiredToStop,
            useDeviceAdminLock = useDeviceAdminLock,
            useOverlayLockScreen = useOverlayLockScreen,
            warningSoundBeforeOneMinute = warningSoundBeforeOneMinute,
            vibrateOnLock = vibrateOnLock,
            mathChallengeEnabled = mathChallengeEnabled,
            mathChallengeIntervalMinutes = mathChallengeIntervalMinutes,
            mathChallengeDurationSeconds = mathChallengeDurationSeconds,
            appLockEnabled = appLockEnabled
        )
    }

    fun updateMathChallengeSettings(enabled: Boolean, intervalMinutes: Int, durationSeconds: Int) {
        preferencesManager.updateMathChallengeSettings(enabled, intervalMinutes, durationSeconds)
    }

    fun addCustomMathQuestion(
        questionText: String,
        correctAnswer: String,
        wrongOption1: String,
        wrongOption2: String,
        difficulty: Int = 1
    ) {
        viewModelScope.launch(Dispatchers.IO) {
            val question = MathQuestionEntity(
                questionText = questionText,
                correctAnswer = correctAnswer,
                wrongOption1 = wrongOption1,
                wrongOption2 = wrongOption2,
                isCustom = true,
                difficulty = difficulty
            )
            mathQuestionDao.insertQuestion(question)
        }
    }

    fun deleteMathQuestion(id: Long) {
        viewModelScope.launch(Dispatchers.IO) {
            mathQuestionDao.deleteById(id)
        }
    }
}
