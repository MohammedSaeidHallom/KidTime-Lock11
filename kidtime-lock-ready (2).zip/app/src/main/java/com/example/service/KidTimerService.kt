package com.example.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.os.Build
import android.os.IBinder
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.provider.Settings
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.data.AppDatabase
import com.example.data.PreferencesManager
import com.example.model.SessionEntity
import com.example.model.TimerStatus
import com.example.ui.challenge.MathChallengeActivity
import com.example.ui.lock.LockScreenActivity
import com.example.util.DeviceLockManager
import com.example.util.UsageStatsHelper
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

class KidTimerService : Service() {

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var timerJob: Job? = null
    private lateinit var notificationManager: NotificationManager
    private lateinit var deviceLockManager: DeviceLockManager
    private lateinit var preferencesManager: PreferencesManager
    private lateinit var usageStatsHelper: UsageStatsHelper
    private var secondsSinceLastMathChallenge = 0
    private var mathDifficulty = 1

    override fun onCreate() {
        super.onCreate()
        notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        deviceLockManager = DeviceLockManager(this)
        preferencesManager = PreferencesManager(this)
        usageStatsHelper = UsageStatsHelper(this)
        createNotificationChannels()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                val durationMinutes = intent.getIntExtra(EXTRA_MINUTES, 15)
                startTimer(durationMinutes)
            }
            ACTION_PAUSE -> {
                pauseTimer()
            }
            ACTION_RESUME -> {
                resumeTimer()
            }
            ACTION_STOP -> {
                stopTimer(completedNaturally = false)
            }
            ACTION_ADD_FIVE_MINUTES -> {
                addMinutes(5)
            }
            ACTION_SUBTRACT_FIVE_MINUTES -> {
                subtractMinutes(5)
            }
            ACTION_ADJUST_ONE_MINUTE -> {
                adjustOneMinute(intent.getIntExtra(EXTRA_MINUTE_SIGN, 0))
            }
        }
        return START_STICKY
    }

    private fun startTimer(minutes: Int) {
        if (_status.value == TimerStatus.RUNNING || _status.value == TimerStatus.PAUSED) return
        val totalSecs = (minutes * 60).toLong().coerceAtLeast(30L)
        _totalSeconds.value = totalSecs
        _remainingSeconds.value = totalSecs
        _status.value = TimerStatus.RUNNING
        _sessionStartTime.value = System.currentTimeMillis()
        _targetMinutes.value = minutes
        secondsSinceLastMathChallenge = 0
        mathDifficulty = 1

        startForeground(NOTIFICATION_ID, buildNotification(_remainingSeconds.value))
        launchCountdown()
    }

    private fun pauseTimer() {
        if (_status.value == TimerStatus.RUNNING) {
            timerJob?.cancel()
            _status.value = TimerStatus.PAUSED
            updateNotification(_remainingSeconds.value)
        }
    }

    private fun resumeTimer() {
        if (_status.value == TimerStatus.PAUSED) {
            _status.value = TimerStatus.RUNNING
            launchCountdown()
        }
    }

    private fun isSessionActive(): Boolean =
        _status.value == TimerStatus.RUNNING || _status.value == TimerStatus.PAUSED

    private fun addMinutes(minutes: Int) {
        if (!isSessionActive()) return
        val addSecs = (minutes * 60).toLong()
        _totalSeconds.value += addSecs
        _remainingSeconds.value += addSecs
        _targetMinutes.value = (_totalSeconds.value / 60L).toInt()
        updateNotification(_remainingSeconds.value)
    }

    private fun subtractMinutes(minutes: Int) {
        if (!isSessionActive()) return
        val rem = _remainingSeconds.value
        val subSecs = (minutes * 60).toLong()
        // Never drop below one minute (or below what is left, if less than that)
        val floor = minOf(rem, 60L)
        val newRemaining = (rem - subSecs).coerceAtLeast(floor)
        val removed = rem - newRemaining
        _remainingSeconds.value = newRemaining
        _totalSeconds.value = (_totalSeconds.value - removed).coerceAtLeast(newRemaining)
        _targetMinutes.value = (_totalSeconds.value / 60L).toInt()
        updateNotification(newRemaining)
    }

    /**
     * نتيجة التمرين: +1 تضيف دقيقة، -1 تنقص دقيقة.
     * إذا استهلكت العقوبة الوقت المتبقي يُقفل الهاتف فوراً.
     */
    private fun adjustOneMinute(sign: Int) {
        if (!isSessionActive()) {
            // الجلسة انتهت: لا شيء لتعديله، نغلق الخدمة
            stopSelf()
            return
        }
        val rem = _remainingSeconds.value
        if (sign > 0) {
            _totalSeconds.value += 60L
            _remainingSeconds.value = rem + 60L
        } else if (sign < 0) {
            val newRem = rem - 60L
            if (newRem <= 0L) {
                _remainingSeconds.value = 0L
                timerJob?.cancel()
                onTimerFinished()
                return
            }
            _remainingSeconds.value = newRem
            _totalSeconds.value = (_totalSeconds.value - 60L).coerceAtLeast(newRem)
        } else {
            return
        }
        _targetMinutes.value = (_totalSeconds.value / 60L).toInt()
        updateNotification(_remainingSeconds.value)
    }

    private fun launchCountdown() {
        timerJob?.cancel()
        timerJob = serviceScope.launch {
            while (isActive && _remainingSeconds.value > 0) {
                delay(1000L)
                _remainingSeconds.value -= 1
                secondsSinceLastMathChallenge += 1

                val settings = preferencesManager.current()
                val intervalSecs = (settings.mathChallengeIntervalMinutes * 60).coerceAtLeast(30)

                // Trigger periodic math challenge if enabled
                if (settings.mathChallengeEnabled &&
                    secondsSinceLastMathChallenge >= intervalSecs &&
                    _remainingSeconds.value > 5
                ) {
                    secondsSinceLastMathChallenge = 0
                    triggerMathChallenge(mathDifficulty)
                    mathDifficulty = (mathDifficulty + 1).coerceAtMost(5)
                }

                // 1-minute audio/vibration warning
                if (_remainingSeconds.value == 60L && settings.warningSoundBeforeOneMinute) {
                    playWarningCue()
                }

                if (_remainingSeconds.value % 5L == 0L || _remainingSeconds.value <= 10L) {
                    updateNotification(_remainingSeconds.value)
                }
            }

            if (_remainingSeconds.value <= 0) {
                onTimerFinished()
            }
        }
    }

    private fun triggerMathChallenge(difficulty: Int) {
        try {
            val challengeIntent = Intent(this, MathChallengeActivity::class.java).apply {
                putExtra(MathChallengeActivity.EXTRA_DIFFICULTY, difficulty)
                putExtra(
                    MathChallengeActivity.EXTRA_TIME_LIMIT_SECONDS,
                    preferencesManager.current().mathChallengeDurationSeconds
                )
                addFlags(
                    Intent.FLAG_ACTIVITY_NEW_TASK or
                            Intent.FLAG_ACTIVITY_CLEAR_TOP or
                            Intent.FLAG_ACTIVITY_SINGLE_TOP or
                            Intent.FLAG_ACTIVITY_REORDER_TO_FRONT
                )
            }

            // Launch with full screen pending intent to take over foreground app
            val pending = PendingIntent.getActivity(
                this,
                888,
                challengeIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            val challengeNotification = NotificationCompat.Builder(this, LOCK_ALARM_CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle("تحدي التفكير الرياضي 🧮")
                .setContentText("أجب على التمرين الرياضي السريع للمتابعة")
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setCategory(NotificationCompat.CATEGORY_ALARM)
                .setFullScreenIntent(pending, true)
                .setAutoCancel(true)
                .build()

            if (Settings.canDrawOverlays(this)) {
                // "Display over other apps" lets the system open the exercise directly on screen,
                // on top of whatever the child is using (no notification to tap).
                startActivity(challengeIntent)
            } else {
                // Fallback when the permission is missing: a full-screen notification
                notificationManager.notify(NOTIFICATION_ID + 3, challengeNotification)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun onTimerFinished() {
        _status.value = TimerStatus.FINISHED
        val endTime = System.currentTimeMillis()
        val startTime = _sessionStartTime.value

        // Record session and apps (saved on a scope that outlives this service)
        saveSession(startTime, endTime, completedNaturally = true)

        // Trigger vibration
        if (preferencesManager.current().vibrateOnLock) {
            triggerVibration()
        }

        // 1. Hardware Screen Lock via Device Policy Manager (if active)
        if (preferencesManager.current().useDeviceAdminLock) {
            deviceLockManager.lockDeviceNow()
        }

        // 2. Full-Screen Kid Lock Screen Overlay using Full-Screen Intent Notification
        // This is guaranteed by Android OS to take over YouTube or any foreground app immediately!
        val lockIntent = Intent(this, LockScreenActivity::class.java).apply {
            addFlags(
                Intent.FLAG_ACTIVITY_NEW_TASK or
                        Intent.FLAG_ACTIVITY_CLEAR_TOP or
                        Intent.FLAG_ACTIVITY_SINGLE_TOP or
                        Intent.FLAG_ACTIVITY_REORDER_TO_FRONT
            )
        }
        val fullScreenPendingIntent = PendingIntent.getActivity(
            this,
            999,
            lockIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        // Respect the parent's "direct child lock screen" toggle
        val overlayOn = preferencesManager.current().useOverlayLockScreen

        val fullScreenLockNotification = NotificationCompat.Builder(this, LOCK_ALARM_CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setContentTitle("انتهى وقت الهاتف! 🔒")
            .setContentText("انتهى وقت الشاشة المسموح به. يرجى تسليم الهاتف لوالديك.")
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .apply { if (overlayOn) setFullScreenIntent(fullScreenPendingIntent, true) }
            .setContentIntent(fullScreenPendingIntent)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setAutoCancel(false)
            .setOngoing(true)
            .build()

        notificationManager.notify(NOTIFICATION_ID + 1, fullScreenLockNotification)

        if (overlayOn) {
            try {
                startActivity(lockIntent)
            } catch (_: Exception) {}
        }

        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun saveSession(startTime: Long, endTime: Long, completedNaturally: Boolean) {
        val targetMins = _targetMinutes.value
        dbScope.launch {
            try {
                val db = AppDatabase.getInstance(applicationContext)
                val apps = usageStatsHelper.getAppsUsedDuringSession(startTime, endTime)
                val session = SessionEntity(
                    startTimeMs = startTime,
                    endTimeMs = endTime,
                    targetMinutes = targetMins,
                    actualDurationMs = (endTime - startTime).coerceAtLeast(0L),
                    completedNaturally = completedNaturally,
                    appsCount = apps.size,
                    topAppName = apps.firstOrNull()?.appName
                        ?: if (completedNaturally) "غير محدد" else "متوقف مبكراً",
                    appsSummary = apps.joinToString(separator = ", ") {
                        "${it.appName} (${it.totalTimeInForegroundMs / 1000} ث)"
                    }
                )
                db.sessionDao().insertSession(session)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    private fun stopTimer(completedNaturally: Boolean) {
        timerJob?.cancel()
        val endTime = System.currentTimeMillis()
        val startTime = _sessionStartTime.value

        if (_status.value == TimerStatus.RUNNING || _status.value == TimerStatus.PAUSED) {
            saveSession(startTime, endTime, completedNaturally)
        }

        _status.value = TimerStatus.IDLE
        _remainingSeconds.value = 0L
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun triggerVibration() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vibratorManager = getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager
                vibratorManager.defaultVibrator.vibrate(
                    VibrationEffect.createWaveform(longArrayOf(0, 500, 200, 600), -1)
                )
            } else {
                @Suppress("DEPRECATION")
                val vibrator = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
                @Suppress("DEPRECATION")
                vibrator.vibrate(500)
            }
        } catch (_: Exception) {}
    }

    private fun playWarningCue() {
        // Audio alert removed per user request: "إزالة التنبيه الصوتي"
        try {
            if (preferencesManager.current().vibrateOnLock) {
                triggerVibration()
            }
        } catch (_: Exception) {}
    }

    /**
     * Builds the persistent countdown notification.
     * CRITICAL: Action buttons (+5m and Stop) are completely REMOVED from the notification
     * so that the child cannot extend screen time or stop the timer from the notification tray!
     */
    private fun buildNotification(remainingSec: Long): Notification {
        val minutes = remainingSec / 60
        val seconds = remainingSec % 60
        val timeFormatted = String.format("%02d:%02d", minutes, seconds)

        val openAppIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP
        }
        val openAppPendingIntent = PendingIntent.getActivity(
            this,
            0,
            openAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("مؤقت وقت الطفل قيد التشغيل ⏳")
            .setContentText("الوقت المتبقي: $timeFormatted دقيقة (محمي برمز الوالدين)")
            .setContentIntent(openAppPendingIntent)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    private fun updateNotification(remainingSec: Long) {
        if (_status.value != TimerStatus.FINISHED) {
            notificationManager.notify(NOTIFICATION_ID, buildNotification(remainingSec))
        }
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            // 1. Countdown channel (Low importance, silent)
            val countdownChannel = NotificationChannel(
                CHANNEL_ID,
                "عد تنازلي وقت الطفل",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "يعرض وقت الشاشة المتبقي للطفل (محمي من تعديل الطفل)"
                setShowBadge(false)
            }
            notificationManager.createNotificationChannel(countdownChannel)

            // 2. Lock Alarm channel (High importance, vibration, fullScreenIntent, SILENT without audio alert)
            val lockChannel = NotificationChannel(
                LOCK_ALARM_CHANNEL_ID,
                "تنبيه قفل شاشة الطفل",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "يفرض قفل الشاشة التلقائي فورا فوق أي تطبيق مشغل عند انتهاء الوقت"
                enableVibration(true)
                setShowBadge(true)
                setBypassDnd(true)
                // Audio alert completely removed per user request: "إزالة التنبيه الصوتي"
                setSound(null, null)
            }
            notificationManager.createNotificationChannel(lockChannel)
        }
    }

    override fun onDestroy() {
        timerJob?.cancel()
        serviceScope.cancel()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val CHANNEL_ID = "kid_timer_countdown_channel"
        const val LOCK_ALARM_CHANNEL_ID = "kid_timer_lock_alarm_channel"
        const val NOTIFICATION_ID = 1001

        const val ACTION_START = "com.example.service.ACTION_START"
        const val ACTION_PAUSE = "com.example.service.ACTION_PAUSE"
        const val ACTION_RESUME = "com.example.service.ACTION_RESUME"
        const val ACTION_STOP = "com.example.service.ACTION_STOP"
        const val ACTION_ADD_FIVE_MINUTES = "com.example.service.ACTION_ADD_FIVE_MINUTES"
        const val ACTION_SUBTRACT_FIVE_MINUTES = "com.example.service.ACTION_SUBTRACT_FIVE_MINUTES"
        const val ACTION_ADJUST_ONE_MINUTE = "com.example.service.ACTION_ADJUST_ONE_MINUTE"
        const val EXTRA_MINUTE_SIGN = "extra_minute_sign"

        const val EXTRA_MINUTES = "extra_minutes"

        // Not cancelled in onDestroy, so session writes finish after the service stops
        private val dbScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

        // Observable State
        private val _remainingSeconds = MutableStateFlow(0L)
        val remainingSeconds: StateFlow<Long> = _remainingSeconds.asStateFlow()

        private val _totalSeconds = MutableStateFlow(0L)
        val totalSeconds: StateFlow<Long> = _totalSeconds.asStateFlow()

        private val _status = MutableStateFlow(TimerStatus.IDLE)
        val status: StateFlow<TimerStatus> = _status.asStateFlow()

        private val _sessionStartTime = MutableStateFlow(0L)
        val sessionStartTime: StateFlow<Long> = _sessionStartTime.asStateFlow()

        private val _targetMinutes = MutableStateFlow(15)
        val targetMinutes: StateFlow<Int> = _targetMinutes.asStateFlow()

        fun start(context: Context, minutes: Int) {
            val intent = Intent(context, KidTimerService::class.java).apply {
                action = ACTION_START
                putExtra(EXTRA_MINUTES, minutes)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun pause(context: Context) {
            val intent = Intent(context, KidTimerService::class.java).apply {
                action = ACTION_PAUSE
            }
            context.startService(intent)
        }

        fun resume(context: Context) {
            val intent = Intent(context, KidTimerService::class.java).apply {
                action = ACTION_RESUME
            }
            context.startService(intent)
        }

        fun stop(context: Context) {
            val intent = Intent(context, KidTimerService::class.java).apply {
                action = ACTION_STOP
            }
            context.startService(intent)
        }

        fun addFiveMinutes(context: Context) {
            val intent = Intent(context, KidTimerService::class.java).apply {
                action = ACTION_ADD_FIVE_MINUTES
            }
            context.startService(intent)
        }

        /** Called by the exercise screen: sign = +1 (correct) or -1 (wrong / no answer). */
        fun adjustOneMinute(context: Context, sign: Int) {
            val intent = Intent(context, KidTimerService::class.java).apply {
                action = ACTION_ADJUST_ONE_MINUTE
                putExtra(EXTRA_MINUTE_SIGN, sign)
            }
            try {
                context.startService(intent)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }

        fun subtractFiveMinutes(context: Context) {
            val intent = Intent(context, KidTimerService::class.java).apply {
                action = ACTION_SUBTRACT_FIVE_MINUTES
            }
            context.startService(intent)
        }
    }
}