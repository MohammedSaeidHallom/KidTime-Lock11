package com.example.model

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class TimerStatus {
    IDLE,
    RUNNING,
    PAUSED,
    FINISHED
}

data class AppUsageInfo(
    val packageName: String,
    val appName: String,
    val totalTimeInForegroundMs: Long,
    val percentageOfSession: Float = 0f,
    val launchCount: Int = 1,
    val category: String = "تطبيق"
)

@Entity(tableName = "sessions")
data class SessionEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val startTimeMs: Long,
    val endTimeMs: Long,
    val targetMinutes: Int,
    val actualDurationMs: Long,
    val completedNaturally: Boolean,
    val appsCount: Int,
    val topAppName: String,
    val appsSummary: String
)

@Entity(tableName = "math_questions")
data class MathQuestionEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val questionText: String,
    val correctAnswer: String,
    val wrongOption1: String,
    val wrongOption2: String,
    val isCustom: Boolean = true,
    val difficulty: Int = 1
)

data class MathChallenge(
    val question: String,
    val correctAnswer: String,
    val options: List<String>,
    val difficultyLevel: Int = 1
)

data class ParentSettings(
    val parentPin: String = "1234",
    val pinRequiredToStop: Boolean = true,
    val useDeviceAdminLock: Boolean = true,
    val useOverlayLockScreen: Boolean = true,
    val warningSoundBeforeOneMinute: Boolean = false,
    val vibrateOnLock: Boolean = true,
    val mathChallengeEnabled: Boolean = true,
    val mathChallengeIntervalMinutes: Int = 5,
    val mathChallengeDurationSeconds: Int = 20,
    val appLockEnabled: Boolean = true
)
