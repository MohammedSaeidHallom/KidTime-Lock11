package com.example.util

import android.app.usage.UsageEvents
import android.content.Intent
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.pm.PackageManager
import com.example.model.AppUsageInfo

class UsageStatsHelper(private val context: Context) {
    private val usageStatsManager =
        context.getSystemService(Context.USAGE_STATS_SERVICE) as? UsageStatsManager
    private val packageManager: PackageManager = context.packageManager

    /** Home-screen launchers differ per phone brand (Samsung, Xiaomi, Pixel...), so detect them. */
    private val launcherPackages: Set<String> by lazy {
        try {
            val homeIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
            packageManager.queryIntentActivities(homeIntent, PackageManager.MATCH_DEFAULT_ONLY)
                .mapNotNull { it.activityInfo?.packageName }
                .toSet()
        } catch (_: Exception) {
            emptySet()
        }
    }

    /**
     * Queries strictly real foreground app activity during the specified session window.
     * No mock data or fake fallbacks will ever be returned.
     */
    fun getAppsUsedDuringSession(startTimeMs: Long, endTimeMs: Long): List<AppUsageInfo> {
        if (usageStatsManager == null || startTimeMs >= endTimeMs) {
            return emptyList()
        }

        val appDurationMap = mutableMapOf<String, Long>()
        val appLaunchCountMap = mutableMapOf<String, Int>()

        // Ignored system components that are not child user apps
        val ignoredPackages = setOf(
            context.packageName,
            "com.android.systemui",
            "com.google.android.inputmethod.latin",
            "com.android.settings"
        ) + launcherPackages

        try {
            // Detailed UsageEvents query
            val events = usageStatsManager.queryEvents(startTimeMs, endTimeMs)
            val event = UsageEvents.Event()
            val appForegroundStart = mutableMapOf<String, Long>()

            while (events.hasNextEvent()) {
                events.getNextEvent(event)
                val pkg = event.packageName ?: continue
                if (pkg in ignoredPackages) continue

                when (event.eventType) {
                    UsageEvents.Event.ACTIVITY_RESUMED -> {
                        appForegroundStart[pkg] = event.timeStamp
                        appLaunchCountMap[pkg] = (appLaunchCountMap[pkg] ?: 0) + 1
                    }
                    UsageEvents.Event.ACTIVITY_PAUSED, UsageEvents.Event.ACTIVITY_STOPPED -> {
                        val start = appForegroundStart.remove(pkg)
                        if (start != null && event.timeStamp > start) {
                            val duration = event.timeStamp - start
                            appDurationMap[pkg] = (appDurationMap[pkg] ?: 0L) + duration
                        }
                    }
                }
            }

            // Close any still-active foreground app at endTimeMs
            appForegroundStart.forEach { (pkg, start) ->
                if (endTimeMs > start) {
                    val duration = endTimeMs - start
                    appDurationMap[pkg] = (appDurationMap[pkg] ?: 0L) + duration
                }
            }
        } catch (_: Exception) {}

        // Fallback or supplementary: check queryUsageStats if queryEvents had empty results
        if (appDurationMap.isEmpty()) {
            try {
                val statsList = usageStatsManager.queryUsageStats(
                    UsageStatsManager.INTERVAL_BEST,
                    startTimeMs,
                    endTimeMs
                )
                if (statsList != null) {
                    for (stat in statsList) {
                        val pkg = stat.packageName ?: continue
                        if (pkg in ignoredPackages) continue

                        if (stat.lastTimeUsed >= startTimeMs && stat.totalTimeInForeground > 1000L) {
                            // Only include if used within the session window
                            val time = stat.totalTimeInForeground.coerceAtMost(endTimeMs - startTimeMs)
                            if (time > 1000L) {
                                appDurationMap[pkg] = time
                                appLaunchCountMap[pkg] = 1
                            }
                        }
                    }
                }
            } catch (_: Exception) {}
        }

        // If no apps were opened during this session, return empty list (NO fake/mock apps)
        if (appDurationMap.isEmpty()) {
            return emptyList()
        }

        val totalTime = appDurationMap.values.sum().coerceAtLeast(1L)
        val resultList = mutableListOf<AppUsageInfo>()

        for ((pkg, duration) in appDurationMap) {
            val appName = getAppLabel(pkg)
            val percentage = (duration.toFloat() / totalTime.toFloat()).coerceIn(0f, 1f)
            val launchCount = appLaunchCountMap[pkg] ?: 1

            resultList.add(
                AppUsageInfo(
                    packageName = pkg,
                    appName = appName,
                    totalTimeInForegroundMs = duration,
                    percentageOfSession = percentage,
                    launchCount = launchCount,
                    category = categorizePackage(pkg)
                )
            )
        }

        return resultList.sortedByDescending { it.totalTimeInForegroundMs }
    }

    private fun getAppLabel(packageName: String): String {
        return try {
            val appInfo = packageManager.getApplicationInfo(packageName, 0)
            packageManager.getApplicationLabel(appInfo).toString()
        } catch (e: Exception) {
            packageName.substringAfterLast('.').replaceFirstChar { it.uppercase() }
        }
    }

    private fun categorizePackage(packageName: String): String {
        val lower = packageName.lowercase()
        return when {
            lower.contains("youtube") || lower.contains("video") || lower.contains("netflix") || lower.contains("media") -> "فيديو وترفيه"
            lower.contains("game") || lower.contains("play") || lower.contains("roblox") -> "ألعاب"
            lower.contains("chrome") || lower.contains("browser") || lower.contains("web") -> "تصفح إنترنت"
            lower.contains("tiktok") || lower.contains("instagram") || lower.contains("whatsapp") || lower.contains("social") -> "تواصل اجتماعي"
            else -> "تطبيق"
        }
    }
}
