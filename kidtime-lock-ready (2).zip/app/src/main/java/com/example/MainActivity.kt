package com.example

import android.content.Intent
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.HourglassTop
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.QueryStats
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.MainViewModel
import com.example.ui.lock.AppLockScreen
import com.example.ui.theme.Amber400
import com.example.ui.theme.Cyan400
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.Slate800
import com.example.ui.tabs.HistoryScreen
import com.example.ui.tabs.SettingsScreen
import com.example.ui.tabs.TimerScreen
import com.example.ui.tabs.UsageStatsScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.Slate700

enum class AppTab(val title: String) {
    TIMER("المؤقت"),
    STATS("الإحصائيات"),
    HISTORY("السجل"),
    SETTINGS("الإعدادات")
}

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            MyApplicationTheme {
                MainApp()
            }
        }
    }
}

@Composable
fun MainApp(viewModel: MainViewModel = viewModel()) {
    var selectedTab by remember { mutableStateOf(AppTab.TIMER) }
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current

    // Request Notifications Permission Launcher
    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { _ ->
        viewModel.checkPermissions()
    }

    // Request Device Admin Permission Launcher
    val deviceAdminLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { _ ->
        viewModel.checkPermissions()
    }

    val requestDeviceAdminAction = {
        try {
            val adminIntent = viewModel.deviceLockManager.getRequestDeviceAdminIntent()
            deviceAdminLauncher.launch(adminIntent)
            android.widget.Toast.makeText(
                context,
                "يرجى الضغط على (تفعيل تطبيق مسؤول الجهاز هذا) لتفعيل قفل الشاشة التلقائي",
                android.widget.Toast.LENGTH_LONG
            ).show()
        } catch (e: Exception) {
            try {
                val fallbackIntent = viewModel.deviceLockManager.getFallbackSecuritySettingsIntent()
                context.startActivity(fallbackIntent)
                android.widget.Toast.makeText(
                    context,
                    "انتقل إلى (تطبيقات مسؤولي الجهاز) وقم بتفعيل KidTimer",
                    android.widget.Toast.LENGTH_LONG
                ).show()
            } catch (_: Exception) {}
        }
    }

    var isParentUnlocked by rememberSaveable { mutableStateOf(false) }

    // Refresh permissions and usage stats whenever activity is resumed,
    // and automatically re-lock when app goes to background to prevent child from tampering
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                viewModel.checkPermissions()
                viewModel.loadUsageStats()
            } else if (event == Lifecycle.Event.ON_STOP) {
                // Whenever child exits or app is minimized, lock app again
                isParentUnlocked = false
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
        }
    }

    // Collect state
    val remainingSeconds by viewModel.remainingSeconds.collectAsState()
    val totalSeconds by viewModel.totalSeconds.collectAsState()
    val timerStatus by viewModel.timerStatus.collectAsState()
    val targetMinutes by viewModel.targetMinutes.collectAsState()
    val settings by viewModel.settings.collectAsState()
    val sessions by viewModel.sessions.collectAsState()
    val appsUsageList by viewModel.appsUsageList.collectAsState()
    val isDeviceAdminActive by viewModel.isDeviceAdminActive.collectAsState()
    val hasUsageStatsPermission by viewModel.hasUsageStatsPermission.collectAsState()
    val hasNotificationPermission by viewModel.hasNotificationPermission.collectAsState()
    val hasOverlayPermission by viewModel.hasOverlayPermission.collectAsState()
    val mathQuestions by viewModel.mathQuestions.collectAsState()

    val isSessionActive = timerStatus == com.example.model.TimerStatus.RUNNING || timerStatus == com.example.model.TimerStatus.PAUSED

    // Handle Back Press on secondary tabs to navigate back to Timer, or re-lock if on Timer
    if (selectedTab != AppTab.TIMER) {
        BackHandler {
            selectedTab = AppTab.TIMER
        }
    } else if (isSessionActive && isParentUnlocked) {
        BackHandler {
            isParentUnlocked = false
        }
    }

    // APP LOCK SCREEN: If countdown is running/paused and App Lock is enabled and parent hasn't authenticated:
    // Display the dedicated child-proof AppLockScreen so child cannot touch, stop, or modify the timer!
    if (isSessionActive && settings.appLockEnabled && !isParentUnlocked) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .windowInsetsPadding(WindowInsets.safeDrawing)
        ) {
            AppLockScreen(
                remainingSeconds = remainingSeconds,
                totalSeconds = totalSeconds,
                status = timerStatus,
                targetMinutes = targetMinutes,
                parentPin = settings.parentPin,
                onUnlockSuccess = {
                    isParentUnlocked = true
                }
            )
        }
        return
    }

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .windowInsetsPadding(WindowInsets.safeDrawing),
        containerColor = DarkBackground,
        bottomBar = {
            NavigationBar(
                containerColor = DarkSurface,
                modifier = Modifier
                    .windowInsetsPadding(WindowInsets.navigationBars)
                    .testTag("bottom_nav_bar")
            ) {
                // 1. Timer Tab
                NavigationBarItem(
                    selected = selectedTab == AppTab.TIMER,
                    onClick = { selectedTab = AppTab.TIMER },
                    icon = {
                        Icon(
                            imageVector = Icons.Default.HourglassTop,
                            contentDescription = "المؤقت"
                        )
                    },
                    label = {
                        Text(
                            text = AppTab.TIMER.title,
                            fontSize = 12.sp,
                            fontWeight = if (selectedTab == AppTab.TIMER) FontWeight.Bold else FontWeight.Normal
                        )
                    },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = DarkBackground,
                        selectedTextColor = Cyan400,
                        indicatorColor = Cyan400,
                        unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                        unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
                    ),
                    modifier = Modifier.testTag("nav_tab_timer")
                )

                // 2. Stats Tab
                NavigationBarItem(
                    selected = selectedTab == AppTab.STATS,
                    onClick = {
                        selectedTab = AppTab.STATS
                        viewModel.loadUsageStats()
                    },
                    icon = {
                        Icon(
                            imageVector = Icons.Default.QueryStats,
                            contentDescription = "الإحصائيات"
                        )
                    },
                    label = {
                        Text(
                            text = AppTab.STATS.title,
                            fontSize = 12.sp,
                            fontWeight = if (selectedTab == AppTab.STATS) FontWeight.Bold else FontWeight.Normal
                        )
                    },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = DarkBackground,
                        selectedTextColor = Cyan400,
                        indicatorColor = Cyan400,
                        unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                        unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
                    ),
                    modifier = Modifier.testTag("nav_tab_stats")
                )

                // 3. History Tab
                NavigationBarItem(
                    selected = selectedTab == AppTab.HISTORY,
                    onClick = { selectedTab = AppTab.HISTORY },
                    icon = {
                        Icon(
                            imageVector = Icons.Default.History,
                            contentDescription = "السجل"
                        )
                    },
                    label = {
                        Text(
                            text = AppTab.HISTORY.title,
                            fontSize = 12.sp,
                            fontWeight = if (selectedTab == AppTab.HISTORY) FontWeight.Bold else FontWeight.Normal
                        )
                    },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = DarkBackground,
                        selectedTextColor = Cyan400,
                        indicatorColor = Cyan400,
                        unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                        unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
                    ),
                    modifier = Modifier.testTag("nav_tab_history")
                )

                // 4. Settings Tab
                NavigationBarItem(
                    selected = selectedTab == AppTab.SETTINGS,
                    onClick = { selectedTab = AppTab.SETTINGS },
                    icon = {
                        Icon(
                            imageVector = Icons.Default.Settings,
                            contentDescription = "الإعدادات"
                        )
                    },
                    label = {
                        Text(
                            text = AppTab.SETTINGS.title,
                            fontSize = 12.sp,
                            fontWeight = if (selectedTab == AppTab.SETTINGS) FontWeight.Bold else FontWeight.Normal
                        )
                    },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = DarkBackground,
                        selectedTextColor = Cyan400,
                        indicatorColor = Cyan400,
                        unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                        unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
                    ),
                    modifier = Modifier.testTag("nav_tab_settings")
                )
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Sticky top indicator when parent has unlocked the controls during an active timer session
            if (isSessionActive && isParentUnlocked) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Slate800)
                        .border(1.dp, Amber400.copy(alpha = 0.5f))
                        .padding(horizontal = 16.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.LockOpen,
                            contentDescription = null,
                            tint = Amber400,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "تحكم الوالدين مفعّل مؤقتاً",
                            color = Color.White,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    TextButton(
                        onClick = { isParentUnlocked = false },
                        colors = ButtonDefaults.textButtonColors(contentColor = Cyan400),
                        modifier = Modifier.testTag("btn_relock_app")
                    ) {
                        Text(
                            text = "إعادة قفل التطبيق 🔒",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            Box(modifier = Modifier.weight(1f)) {
                when (selectedTab) {
                    AppTab.TIMER -> {
                        TimerScreen(
                            remainingSeconds = remainingSeconds,
                            totalSeconds = totalSeconds,
                            status = timerStatus,
                            targetMinutes = targetMinutes,
                            parentPin = settings.parentPin,
                            pinRequiredToStop = settings.pinRequiredToStop,
                            isDeviceAdminActive = isDeviceAdminActive,
                            onStartTimer = { mins -> viewModel.startTimer(mins) },
                            onPauseTimer = { viewModel.pauseTimer() },
                            onResumeTimer = { viewModel.resumeTimer() },
                            onStopTimer = { viewModel.stopTimer() },
                            onAddFiveMinutes = { viewModel.addFiveMinutes() },
                            onSubtractFiveMinutes = { viewModel.subtractFiveMinutes() },
                            onRequestDeviceAdmin = requestDeviceAdminAction
                        )
                    }

                    AppTab.STATS -> {
                        UsageStatsScreen(
                            appsUsageList = appsUsageList,
                            hasUsageStatsPermission = hasUsageStatsPermission,
                            isTimerRunning = timerStatus == com.example.model.TimerStatus.RUNNING,
                            onRequestUsagePermission = {
                                context.startActivity(viewModel.deviceLockManager.getRequestUsageStatsIntent())
                            },
                            onRefreshStats = { viewModel.loadUsageStats() }
                        )
                    }

                    AppTab.HISTORY -> {
                        HistoryScreen(
                            sessions = sessions,
                            onClearHistory = { viewModel.clearHistory() }
                        )
                    }

                    AppTab.SETTINGS -> {
                        SettingsScreen(
                            settings = settings,
                            mathQuestions = mathQuestions,
                            isDeviceAdminActive = isDeviceAdminActive,
                            hasUsageStatsPermission = hasUsageStatsPermission,
                            hasNotificationPermission = hasNotificationPermission,
                            hasOverlayPermission = hasOverlayPermission,
                            onRequestOverlay = {
                                context.startActivity(viewModel.deviceLockManager.getRequestOverlayIntent())
                            },
                            onRequestDeviceAdmin = requestDeviceAdminAction,
                            onRequestUsageStats = {
                                context.startActivity(viewModel.deviceLockManager.getRequestUsageStatsIntent())
                            },
                            onRequestNotification = {
                                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                                    notificationPermissionLauncher.launch(android.Manifest.permission.POST_NOTIFICATIONS)
                                }
                            },
                            onSavePin = { pin -> viewModel.saveParentPin(pin) },
                            onUpdateSettings = { pinReq, adminLock, overlayLock, soundWarn, vibrate, mathEnabled, mathInterval, mathDuration, appLock ->
                                viewModel.updateSettings(pinReq, adminLock, overlayLock, soundWarn, vibrate, mathEnabled, mathInterval, mathDuration, appLock)
                            },
                            onAddMathQuestion = { q, a, w1, w2, diff ->
                                viewModel.addCustomMathQuestion(q, a, w1, w2, diff)
                            },
                            onDeleteMathQuestion = { id ->
                                viewModel.deleteMathQuestion(id)
                            }
                        )
                    }
                }
            }
        }
    }
}
